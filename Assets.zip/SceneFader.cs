using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using static GameController;

public class SceneFader : MonoBehaviour
{
    
    public Image fadeImage;
    public float fadeSpeed = 1.0f;
    

    private bool isFadingOut = false;

    void Start()
    {

        StartCoroutine(FadeIn());
    }

    public void FadeToScene()
    {
        
        StartCoroutine(FadeOut());
        StartCoroutine(SceneLoad());
    }

    IEnumerator SceneLoad()
    {
        yield return new WaitForSeconds(fadeSpeed);
        FadeIn();
        SceneManager.LoadScene("Title");
    }

    IEnumerator FadeIn()
    {
        float alpha = 1.0f;
        while (alpha > 0)
        {
            alpha -= Time.deltaTime * fadeSpeed;
            fadeImage.color = new Color(0, 0, 0, alpha);
            yield return null;

        }
    }

    IEnumerator FadeOut()
    {
        if (isFadingOut)
            yield break;
        isFadingOut = true;

        float alpha = 0.0f;
        while (alpha < 1)
        {
            alpha += Time.deltaTime * fadeSpeed;
            fadeImage.color = new Color(0,0,0,alpha);
            yield return null;
        }
    }   

    // Update is called once per frame
    void Update()
    {
        if (Input.anyKey)
        {
            FadeToScene();
        }
    }
}
