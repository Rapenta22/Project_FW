using System.Collections;
using UnityEngine;

public class SelectionPannelController : MonoBehaviour
{
    public Animator animator;
    public GameObject FirstButton;
    public GameObject SecondButton;
    public GameObject selectionPannel;
    public GameObject resultPannel;

    public void OnFirstButtonClick()
    {
        Debug.Log("First ��ư�� Ŭ���Ǿ����ϴ�.");
        GameController.gameControl.OnYesButtonClick();
        Animator selectionPannelAnimator = selectionPannel.GetComponent<Animator>();
        selectionPannelAnimator.SetTrigger("DoHide");
        StartCoroutine(ShowResultPanelWithDelay());
    }

    public void OnSecondButtonClick()
    {
        Debug.Log("Second ��ư�� Ŭ���Ǿ����ϴ�.");
        GameController.gameControl.OnNoButtonClick();
        Animator selectionPannelAnimator = selectionPannel.GetComponent<Animator>();
        selectionPannelAnimator.SetTrigger("DoHide");
        Animator resultPannelAnimator = resultPannel.GetComponent<Animator>();
        resultPannelAnimator.SetTrigger("DoShow");
    }

    private IEnumerator ShowResultPanelWithDelay()
    {
        yield return new WaitForSeconds(1.5f);
        Animator resultPannelAnimator = resultPannel.GetComponent<Animator>();
        resultPannelAnimator.SetTrigger("DoShow");
    }
}
