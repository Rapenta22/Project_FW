using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class DayN : MonoBehaviour
{
    public TextMeshProUGUI dayText;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        dayText?.SetText($"Day {GameController.gameControl.currentDay}");
    }
}
