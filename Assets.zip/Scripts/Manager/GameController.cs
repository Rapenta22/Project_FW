using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
using System.IO;

public class GameController : MonoBehaviour
{
    public static GameController gameControl;

    public int currentDay = 1;
    public TextMeshProUGUI dayText;
    public TextMeshProUGUI selectionText;
    public TextMeshProUGUI fbText;
    public TextMeshProUGUI sbText;
    public TextMeshProUGUI resultText;

    public struct CardValue
    {
        public int resource, food, fans, turn_resource, turn_food;
        public string description;
        public string result;
    }

    public struct CardState
    {
        public string title;
        public CardValue yes, no;
    }

    public struct GameState
    {
        public int resource, food, fans, turn_resource, turn_food, turn_consumption_resource, turn_consumption_food;
    }

    public GameState currentState;
    public List<CardState> cards;
    public List<CardState> newEventCards;
    public CardState fixedEvent15;
    public CardState fixedEvent28;
    public CardState fixedEvent29;
    public CardState fixedEvent30;
    public bool yesSelected;
    private List<CardState> availableCards;
    private CardState currentCard;

    void Awake()
    {
        DontDestroyOnLoad(gameObject);

        if (gameControl == null)
        {
            gameControl = this;
        }
        else if (gameControl != this)
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        // �ʱ� �ڿ� ����
        currentState.resource = 500;
        currentState.food = 500;
        currentState.fans = 50;

        LoadCardsFromCSV("cards", out cards); // 1~14���� ������
        LoadFixedEventFromCSV("fixedEvent15", out fixedEvent15); // 15���� ���� �̺�Ʈ
        LoadCardsFromCSV("newEvents", out newEventCards); // 16~27���� ������
        LoadFixedEventFromCSV("fixedEvent28", out fixedEvent28); // 28���� ���� �̺�Ʈ
        LoadFixedEventFromCSV("fixedEvent29", out fixedEvent29); // 29���� ���� �̺�Ʈ
        LoadFixedEventFromCSV("fixedEvent30", out fixedEvent30); // 30���� ���� �̺�Ʈ

        LoadInitialValuesFromCSV("Simulations");

        availableCards = new List<CardState>(cards);
        UpdateDayText();
        if (currentDay > 1)
        {
            ApplyTurnResourceAndFood();
        }
        DisplayRandomCard();
    }

    void Update()
    {
        if (IsGameOver())
        {
            currentState.resource = 500;
            currentState.food = 500;
            currentState.fans = 50;
            SceneManager.LoadScene("GameOverScene");
        }
        else if (ClearedGame())
        {
            currentState.resource = 500;
            currentState.food = 500;
            currentState.fans = 50;
            SceneManager.LoadScene("GameClearScene");
        }
    }

    public bool IsGameOver()
    {
        return currentState.resource <= 0 || currentState.food <= 0 || currentState.fans <= 0;
    }

    public bool ClearedGame()
    {
        return currentDay >= 31;
    }

    private void LoadCardsFromCSV(string fileName, out List<CardState> cardList)
    {
        cardList = new List<CardState>();
        TextAsset csvData = Resources.Load<TextAsset>(fileName);

        if (csvData == null)
        {
            Debug.LogError($"CSV file {fileName} not found!");
            return;
        }

        using (StringReader reader = new StringReader(csvData.text))
        {
            string headerLine = reader.ReadLine(); // Skip the header line
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                var values = ParseCSVLine(line);

                if (values.Length != 15)
                {
                    Debug.LogError("Incorrect format in line: " + line);
                    continue;
                }

                try
                {
                    var card = new CardState
                    {
                        title = values[0],
                        yes = new CardValue
                        {
                            description = values[1],
                            result = values[2],
                            resource = int.Parse(values[3]),
                            food = int.Parse(values[4]),
                            fans = int.Parse(values[5]),
                            turn_resource = int.Parse(values[6]),
                            turn_food = int.Parse(values[7])
                        },
                        no = new CardValue
                        {
                            description = values[8],
                            result = values[9],
                            resource = int.Parse(values[10]),
                            food = int.Parse(values[11]),
                            fans = int.Parse(values[12]),
                            turn_resource = int.Parse(values[13]),
                            turn_food = int.Parse(values[14])
                        }
                    };

                    cardList.Add(card);
                }
                catch (System.Exception ex)
                {
                    Debug.LogError("Error parsing line: " + line + " Exception: " + ex.Message);
                }
            }
        }
    }

    private void LoadFixedEventFromCSV(string fileName, out CardState fixedEvent)
    {
        fixedEvent = new CardState();
        TextAsset csvData = Resources.Load<TextAsset>(fileName);

        if (csvData == null)
        {
            Debug.LogError($"CSV file {fileName} not found!");
            return;
        }

        using (StringReader reader = new StringReader(csvData.text))
        {
            string headerLine = reader.ReadLine(); // Skip the header line
            string line = reader.ReadLine();
            if (line != null)
            {
                var values = ParseCSVLine(line);

                if (values.Length != 15)
                {
                    Debug.LogError("Incorrect format in line: " + line);
                    return;
                }

                try
                {
                    fixedEvent = new CardState
                    {
                        title = values[0],
                        yes = new CardValue
                        {
                            description = values[1],
                            result = values[2],
                            resource = int.Parse(values[3]),
                            food = int.Parse(values[4]),
                            fans = int.Parse(values[5]),
                            turn_resource = int.Parse(values[6]),
                            turn_food = int.Parse(values[7])
                        },
                        no = new CardValue
                        {
                            description = values[8],
                            result = values[9],
                            resource = int.Parse(values[10]),
                            food = int.Parse(values[11]),
                            fans = int.Parse(values[12]),
                            turn_resource = int.Parse(values[13]),
                            turn_food = int.Parse(values[14])
                        }
                    };
                }
                catch (System.Exception ex)
                {
                    Debug.LogError("Error parsing line: " + line + " Exception: " + ex.Message);
                }
            }
        }
    }

    private void LoadInitialValuesFromCSV(string fileName)
    {
        TextAsset csvData = Resources.Load<TextAsset>(fileName);

        if (csvData == null)
        {
            Debug.LogError($"CSV file {fileName} not found!");
            return;
        }

        using (StringReader reader = new StringReader(csvData.text))
        {
            string line;
            bool firstLine = true;

            while ((line = reader.ReadLine()) != null)
            {
                if (firstLine)
                {
                    firstLine = false;
                    continue; // Skip header line
                }

                var values = ParseCSVLine(line);

                if (values[0] == "�ʱ�")
                {
                    currentState.resource = int.Parse(values[1]);
                    currentState.food = int.Parse(values[2]);
                    currentState.fans = int.Parse(values[5]);
                }
                else if (values[0] == $"{currentDay}����")
                {
                    currentState.turn_resource = int.Parse(values[1]);
                    currentState.turn_food = int.Parse(values[2]);
                    currentState.turn_consumption_resource = int.Parse(values[3]);
                    currentState.turn_consumption_food = int.Parse(values[4]);
                }
            }
        }
    }

    private string[] ParseCSVLine(string line)
    {
        List<string> values = new List<string>();
        bool inQuotes = false;
        string value = "";

        foreach (char c in line)
        {
            if (c == '"')
            {
                inQuotes = !inQuotes;
            }
            else if (c == ',' && !inQuotes)
            {
                values.Add(value.Trim());
                value = "";
            }
            else
            {
                value += c;
            }
        }
        values.Add(value.Trim());

        return values.ToArray();
    }

    private void DisplayRandomCard()
    {
        if (currentDay == 15)
        {
            DisplayFixedEventCard(fixedEvent15);
        }
        else if (currentDay >= 16 && currentDay <= 27)
        {
            DisplayRandomNewEventCard();
        }
        else if (currentDay == 28)
        {
            DisplayFixedEventCard(fixedEvent28);
        }
        else if (currentDay == 29)
        {
            DisplayFixedEventCard(fixedEvent29);
        }
        else if (currentDay == 30)
        {
            DisplayFixedEventCard(fixedEvent30);
        }
        else
        {
            DisplayRandomBaseCard();
        }
    }

    private void DisplayFixedEventCard(CardState fixedEvent)
    {
        currentCard = fixedEvent;
        selectionText.SetText(currentCard.title);
        fbText.SetText(currentCard.yes.description);
        sbText.SetText(currentCard.no.description);
    }

    private void DisplayRandomNewEventCard()
    {
        if (newEventCards.Count == 0)
        {
            Debug.LogError("No new event cards to display!");
            return;
        }

        int randomIndex = Random.Range(0, newEventCards.Count);
        currentCard = newEventCards[randomIndex];
        newEventCards.RemoveAt(randomIndex);

        selectionText.SetText(currentCard.title);
        fbText.SetText(currentCard.yes.description);
        sbText.SetText(currentCard.no.description);
    }

    private void DisplayRandomBaseCard()
    {
        if (availableCards.Count == 0)
        {
            Debug.LogError("No available cards to display!");
            return;
        }

        int randomIndex = Random.Range(0, availableCards.Count);
        currentCard = availableCards[randomIndex];
        availableCards.RemoveAt(randomIndex);

        selectionText.SetText(currentCard.title);
        fbText.SetText(currentCard.yes.description);
        sbText.SetText(currentCard.no.description);
    }

    public void OnYesButtonClick()
    {
        ApplyCardEffects(currentCard.yes);
        resultText.SetText(currentCard.yes.result);
        yesSelected = true;
        ApplyTurnConsumption();
    }

    public void OnNoButtonClick()
    {
        ApplyCardEffects(currentCard.no);
        resultText.SetText(currentCard.no.result);
        yesSelected = false;
        ApplyTurnConsumption();
    }

    public void OnNextDayButtonClick()
    {
        NextDay();
    }

    private void ApplyCardEffects(CardValue card)
    {
        currentState.resource += card.resource;
        currentState.food += card.food;
        currentState.fans += card.fans;
        currentState.turn_resource += card.turn_resource;
        currentState.turn_food += card.turn_food;

        // �ν��� �ִ� 100�� �ʰ����� �ʵ��� ����
        if (currentState.fans > 100)
        {
            currentState.fans = 100;
        }

        // �ڿ��� 0�� �Ǹ� ���� ���� ó��
        if (IsGameOver())
        {
            SceneManager.LoadScene("GameOverScene");
        }
    }

    private void ApplyTurnResourceAndFood()
    {
        currentState.resource += currentState.turn_resource;
        currentState.food += currentState.turn_food;

        // �ν��� �ִ� 100�� �ʰ����� �ʵ��� ����
        if (currentState.fans > 100)
        {
            currentState.fans = 100;
        }

        // �ڿ��� 0�� �Ǹ� ���� ���� ó��
        if (IsGameOver())
        {
            SceneManager.LoadScene("GameOverScene");
        }
    }

    private void ApplyTurnConsumption()
    {
        currentState.resource -= currentState.turn_consumption_resource;
        currentState.food -= currentState.turn_consumption_food;

        // �ν��� �ִ� 100�� �ʰ����� �ʵ��� ����
        if (currentState.fans > 100)
        {
            currentState.fans = 100;
        }

        // �ڿ��� 0�� �Ǹ� ���� ���� ó��
        if (IsGameOver())
        {
            SceneManager.LoadScene("GameOverScene");
        }
    }

    public void NextDay()
    {
        currentDay++;
        LoadInitialValuesFromCSV("Simulations");
        ApplyTurnResourceAndFood();
        UpdateDayText();
        DisplayRandomCard();
    }

    private void UpdateDayText()
    {
        dayText.SetText($"Day {currentDay}");
    }
}

