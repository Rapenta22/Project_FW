using TMPro;
using UnityEngine;

public class ResourceController : MonoBehaviour
{
    public static ResourceController Instance;

    public TextMeshProUGUI Tech;
    public TextMeshProUGUI Food;
    public TextMeshProUGUI Follower;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else if (Instance != this)
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        if (GameController.gameControl == null)
        {
            Debug.LogError("GameController is not initialized");
            return;
        }

        UpdateResourceTexts();
    }

    public void UpdateResourceTexts()
    {
        var gameObject = GameController.gameControl;
        if (gameObject != null)
        {
            Tech?.SetText($"�ڿ�: {gameObject.currentState.resource}");
            Food?.SetText($"�ķ�: {gameObject.currentState.food}");
            Follower?.SetText($"�ν�: {gameObject.currentState.fans}");
        }
        else
        {
            Debug.LogError("GameController instance not found!");
        }
    }
}
