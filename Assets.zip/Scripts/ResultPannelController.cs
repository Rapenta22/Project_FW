using UnityEngine;

public class ResultPannelController : MonoBehaviour
{
    public Animator animator;
    public GameObject sealButton;
    public GameObject nextDayButton;
    public GameObject resultPannel;

    public void OnNextDayButtonClick()
    {
        Debug.Log("NextDay ��ư�� Ŭ���Ǿ����ϴ�.");
        Animator resultPannelAnimator = resultPannel.GetComponent<Animator>();
        resultPannelAnimator.SetTrigger("DoHide");
        sealButton.SetActive(true);
        GameController.gameControl.NextDay();

        // �ڿ��� ������Ʈ �߰�
        ResourceController.Instance.UpdateResourceTexts();
    }
}
