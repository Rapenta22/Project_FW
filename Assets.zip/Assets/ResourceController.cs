using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ResourceController : MonoBehaviour
{
    public TextMeshProUGUI Tech;
    public TextMeshProUGUI Food;
    public TextMeshProUGUI Follower;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        var gameObject = GameController.gameControl;
        Tech?.SetText($"Tech: {gameObject.currentState.resource}");
        Food?.SetText($"Food: {gameObject.currentState.food}");
        Follower?.SetText($"Follower: {gameObject.currentState.fans}");
    }
}
