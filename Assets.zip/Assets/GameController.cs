using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public static GameController gameControl;

    //���� ����
    public bool IsGameOver()
    {
        return currentState.resource <= 0 || currentState.food <= 0 || currentState.fans <= 0;
    }
    //���� Ŭ����
    public bool ClearedGame()
    {
        return GameController.gameControl.currentDay >= 31;
    }
    

    
    // ī�� ����
    const int NUM_CARDS = 70;
    const int NUM_DAYS = 30;

    public struct CardValue
    {
        public int resource, food, fans, turn_resource, turn_food, turn_fans;
        public string description;
        public string result;

        public override string ToString() => $"resource({resource}), food({food}), fans({fans}), turn_resource({turn_resource}), turn_food({turn_food}), turn_fans({turn_fans})";

    }

    public struct CardState
    {
        public string title;
        public string description;
        public CardValue yes, no;
    }
    
    public struct GameState
    {
        public int resource, food, fans, turn_resource, turn_food, turn_fans;
        public override string ToString() => $"resource({resource}), food({food}), fans({fans}), turn_resource({turn_resource}), turn_food({turn_food}), turn_fans({turn_fans})";
    };

    public GameState currentState;
    public GameState[] dailyDeltaState;
    public CardState[] cards;
   
    private int stage = 0;
    private float currentElapsedTime;

    public int currentDay;
    public int[] indices;
    public bool yesSelected;

    static private class RandomHelper<T>
    {
        static public T[] Choose(T[] items, int numRequired)
        {
            T[] result = new T[numRequired];
            int numToChoose = numRequired;

            for (int numLeft = items.Length; numLeft > 0; numLeft--)
            {

                float prob = (float)numToChoose / (float)numLeft;

                if (UnityEngine.Random.value <= prob)
                {
                    numToChoose--;
                    result[numToChoose] = items[numLeft - 1];

                    if (numToChoose == 0)
                    {
                        break;
                    }
                }
            }
            return result;
        }

        static public void Shuffle(T[] deck)
        {
            for (int i = 0; i < deck.Length; i++)
            {
                T temp = deck[i];
                int randomIndex = UnityEngine.Random.Range(i, deck.Length);
                deck[i] = deck[randomIndex];
                deck[randomIndex] = temp;
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        // ó�� �ڿ��� ����
        currentState.resource = 500;
        currentState.food = 500;
        currentState.fans = 50;
        currentState.turn_resource = 0;
        currentState.turn_food = 0;
        currentState.turn_fans = 0;

        cards = new CardState[NUM_CARDS + 1];
        dailyDeltaState = new GameState[NUM_DAYS + 1];

        for(int day = 1; day <= 15; ++day)
        {
            dailyDeltaState[day] = new GameState();
            dailyDeltaState[day].food = 50;
            dailyDeltaState[day].fans = 0;
            dailyDeltaState[day].resource = 50;
        }
        for(int day = 16; day <= 25; ++day)
        {
            dailyDeltaState[day] = new GameState();
            dailyDeltaState[day].food = -100;
            dailyDeltaState[day].fans = -2;
            dailyDeltaState[day].resource = -100;
        }
        for (int day = 26; day <= 30; ++day)
        {
            dailyDeltaState[day] = new GameState();
            dailyDeltaState[day].food = -200;
            dailyDeltaState[day].fans = -5;
            dailyDeltaState[day].resource = -200;
        }




        // �� �ܰ躰 �귯�� �ð� �ʱ�ȭ
        currentElapsedTime = 0.0f;

        // ���� ������ ī���� �ε��� ����
        currentDay = 1;

        for (int idx = 1; idx <= NUM_CARDS; ++idx)
        {
            var textFile = Resources.Load<TextAsset>("Stories/" + idx);
            if (textFile == null)
                continue;
            var lines = textFile.text.Split("\n");
            if (lines.Length >= 1)
            {
                // ù��° �� �б�
                var firstLine = lines[0];
                var args = firstLine.Split(" ");
                if (args.Length != 6)
                    continue;
                int v;
                bool bad = false;
                foreach (var arg in args)
                {
                    if (!int.TryParse(arg, out v))
                    {
                        bad = true;
                        break;
                    }
                }
                if (bad)
                {
                    continue;
                }
                // �Է��� ������ ����
                cards[idx].yes.resource = int.Parse(args[0]);
                cards[idx].yes.turn_resource = int.Parse(args[1]);
                cards[idx].yes.food = int.Parse(args[2]);
                cards[idx].yes.turn_food = int.Parse(args[3]);
                cards[idx].yes.fans = int.Parse(args[4]);
                cards[idx].yes.turn_fans = int.Parse(args[5]);
            }
            if (lines.Length >= 2)
            {
                // �ι�° �� �б�
                var secondLine = lines[1];
                var args = secondLine.Split(" ");
                if (args.Length != 6)
                    continue;
                int v;
                bool bad = false;
                foreach (var arg in args)
                {
                    if (!int.TryParse(arg, out v))
                    {
                        bad = true;
                        break;
                    }
                }
                if (bad)
                {
                    continue;
                }
                // �Է��� ������ ����
                cards[idx].no.resource = int.Parse(args[0]);
                cards[idx].no.turn_resource = int.Parse(args[1]);
                cards[idx].no.food = int.Parse(args[2]);
                cards[idx].no.turn_food = int.Parse(args[3]);
                cards[idx].no.fans = int.Parse(args[4]);
                cards[idx].no.turn_fans = int.Parse(args[5]);
            }
            if (lines.Length >= 3)
            {
                // ����° �ٸ� �б�(����)
                cards[idx].title = lines[2];
            }
            if (lines.Length >= 4)
            {
                // �׹�° �ٸ� �б�(YesBtn)
                cards[idx].yes.description = lines[3];
            }
            if (lines.Length >= 5)
            {
                // �ټ���° �ٸ� �б�(NoBtn)
                cards[idx].no.description = lines[4];
            }
            if (lines.Length >= 6)
            {
                // ������° �ٸ� �б�(YesBtn���ÿ� ���� ����� ǥ��)
                cards[idx].yes.result = lines[5];
                Debug.Log(cards[idx].yes.result);
                
            }
            if (lines.Length >= 7)
            {
                // ������° �ٸ� �б�(NoBtn���ÿ� ���� ����� ǥ��)
                cards[idx].no.result = lines[6];
            }

            if (lines.Length >= 8)
            {
                //�׹�° �ٺ��� ������ �ٱ��� �б�
                cards[idx].description = String.Join("\n", lines.Skip(7));
            }
        }

        // ī�� ���� �����
        indices = new int[NUM_CARDS + 1];

        // ī�� ����
        shuffleCards();
    }

    // Update is called once per frame
    void Update()
    {

    }

    void Awake()
    {
        DontDestroyOnLoad(gameObject);

        if (gameControl == null)
        {
            gameControl = this;
        }
        else if (gameControl != this)
        {
            Destroy(gameObject);
        }
    }
    private void shuffleCards()
    {
        // ī�� ����
        // 1, 15, 28, 29, 30�� ����
        // 15
        indices[1] = 1;
        // 2~14, 31~50 ����
        int[] part = new int[33];
        int i = 0;
        for (int j = 2; j <= 14; ++j)
        {
            part[i++] = j;
        }
        for (int j = 31; j <= 50; ++j)
        {
            part[i++] = j;
        }
        part = RandomHelper<int>.Choose(part, 13);
        RandomHelper<int>.Shuffle(part);
        for (int j = 2; j <= 14; ++j)
        {
            indices[j] = part[j - 2];
        }
        // 15
        indices[15] = 15;
        // 16~27, 61~70 ����
        part = new int[32];
        i = 0;
        for (int j = 16; j <= 27; ++j)
        {
            part[i++] = j;
        }
        for (int j = 51; j <= 70; ++j)
        {
            part[i++] = j;
        }
        part = RandomHelper<int>.Choose(part, 12);
        RandomHelper<int>.Shuffle(part);
        for (int j = 16; j <= 27; ++j)
        {
            indices[j] = part[j - 16];
        }
        //28
        indices[28] = 28;
        //29
        indices[29] = 29;
        // 30
        indices[30] = 30;
    }

    public void nextDay()
    {
        // �������� �Ѿ�� ���� ���� ��ư�� ��ȭ���� ó���Ѵ�
        var currentCardIndex = indices[currentDay];

        //���� �ڿ� ������ ó��
        currentState.resource += currentState.turn_resource + dailyDeltaState[currentDay].resource;
        currentState.food += currentState.turn_food + dailyDeltaState[currentDay].food;
        currentState.fans += currentState.turn_fans + dailyDeltaState[currentDay].fans;

        if (yesSelected)
        {
            currentState.resource += cards[currentCardIndex].yes.resource;
            currentState.turn_resource += cards[currentCardIndex].yes.turn_resource;
            currentState.food += cards[currentCardIndex].yes.food;
            currentState.turn_food += cards[currentCardIndex].yes.turn_food;
            currentState.fans += cards[currentCardIndex].yes.fans;
            currentState.turn_fans += cards[currentCardIndex].yes.turn_fans;
        }
        else
        {
            currentState.resource += cards[currentCardIndex].no.resource;
            currentState.turn_resource += cards[currentCardIndex].no.turn_resource;
            currentState.food += cards[currentCardIndex].no.food;
            currentState.turn_food += cards[currentCardIndex].no.turn_food;
            currentState.fans += cards[currentCardIndex].no.fans;
            currentState.turn_fans += cards[currentCardIndex].no.turn_fans;
        }

        currentDay += 1;
    }
}


